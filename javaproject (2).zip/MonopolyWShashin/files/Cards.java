package files;

/**
 * Handles the Community Chest and Chance cards
 *
 * @author shashingupta
 * @version May 14, 2021
 */

public class Cards
{

    /**
     * Player its owned by
     */
    public Player player;
    /**
     * Positive or negative change in money in millions as directed by the card
     * (could be 0)
     */
    public double moneyChange;
    /**
     * The position change as directed by the card (added or subtracted), could
     * be 0
     */
    public int    positionChange;
    /**
     * The enw position change as directed by the card (set), could be 0
     */
    public int    newPosition;
    /**
     * Name of the action of the card (the story)
     */
    public String title;
    /**
     * The type of card (Must be "Community Chest" or "Chance")
     */
    public String type;

    /**
     * Creates a new Cards object without a position change
     *
     * @param moneyChange
     *            pos or neg change in money in mil
     * @param title
     *            name of the story for why paying
     */
    public Cards(double moneyChange, String title)
    {
        this.moneyChange = moneyChange;
        this.title = title;
        type = title;
    }


    /**
     * Creates a new Cards object with a change in position (assumes double in
     * rent if applicable)
     *
     * @param title
     *            story for why moving
     * @param positionChange
     *            pos or neg change in position, added. could be 0
     * @param newPostion
     *            index of new position (0 to 47)
     */
    public Cards(String title, int positionChange, int newPostion)
    {
        this.positionChange = positionChange;
        this.title = title;
        this.newPosition = newPostion;
    }


    /**
     * sets the owner of the card, usually when drawn (Called by Player class).
     *
     * @param player
     *            the new owner
     */
    public void setOwner(Player player)
    {
        this.player = player;
    }


    /**
     * Does the action, called by the Player class.
     */
    public void doAction()
    {
        if (player == null)
        {
            return;
        }
        if (moneyChange == 0)
        {
            move();

        }
        else
        {
            transaction();
        }
    }


    /**
     * handles a money transaction.
     */
    private void transaction()
    {
        Transaction a = new Transaction(player.getFactor(), player.Messages());
        a.payBank(player, moneyChange, type);
        player.houses();
    }


    /**
     * handles a position change.
     */
    private void move()
    {
        if (positionChange == 0 && newPosition != 11)
        {
            player.setPosition(newPosition);
            player.Messages().moveTo(title, player, player.newProperty().getName());
            player.TurnAfterChanceMoved();
        }
        else if (newPosition == 11)
        {
            player.goToJail();
        }
        else if (positionChange != 0 && newPosition < 0)
        {
            player.setPosition(player.getPosition() + positionChange);
            player.Messages().moveTo(title, player, player.newProperty().getName());
            player.TurnAfterChanceMoved();
        }
    }


    /**
     * Returns the story of why the Player is paying/moving.
     *
     * @return String the story
     */
    public String statement()
    {
        return title;
    }

}
