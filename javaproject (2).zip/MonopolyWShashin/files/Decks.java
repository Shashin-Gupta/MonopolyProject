package files;

import java.awt.*;
import java.util.LinkedList;

/**
 * represents the three decks used in monopoly. Returns an array of the created
 * PropertyCards including all the rent prices, names, colors, when called by
 * the GameRunner who then creates the Players and other classes as necessary
 * with the PropertyCard array. Keeps the chance and community card decks
 * private and returns a card when “drawn” or called by the GameRunner class.
 *
 * @author shashingupta
 * @version May 27, 2021
 */
public class Decks
{

    private LinkedList<Cards> chanceDeck;
    private LinkedList<Cards> ccDeck;
    private String[]          propertyNames      =
        { "Go", "Oriental Avenue", "Community Chest", "Vermont Avenue", "Connecticut Avenue",
            "Jail", "St. Charles Place", "Chance", "State Avenue", "Virgina Avenue", "Free Parking",
            "Kentucky Avenue", "Community Chest", "Indiana Avenue", "Illinois Avenue", "Go to Jail",
            "Pacific Avenue", "North Carolina Avenue", "Chance", "Pennsylvania Avenue" };
    private PropertyCard[]    properties         = new PropertyCard[propertyNames.length];
    private double[]          propertyPrices     =
        { 2, 1, 0, 1, 1.2, 0, 1.4, 0, 1.4, 1.6, 0, 2.2, 0, 2.2, 2.4, 0, 3, 3, 0, 3.2 };
    private double[][]        propertyPriceLists = { null, { 0.06, 0.3, 0.9, 2.7, 4, 5.5 }, null,
        { 0.06, 0.3, 0.9, 2.7, 4, 5.5 }, { 0.08, 0.4, 1, 3, 4.5, 6 }, null,
        { 0.1, 0.5, 1.5, 4.5, 6.25, 7.5 }, null, { 0.12, 0.6, 1.8, 5, 7, 9 }, { 0.25, 0.5, 1, 2 },
        null, { 0.18, 0.9, 2.5, 7, 8.75, 10.5 }, null, { 0.18, 0.9, 2.5, 7, 8.75, 10.5 },
        { 0.2, 1, 3, 7.5, 9.25, 11 }, null, { 0.26, 1.3, 3.9, 9, 11, 12.75 },
        { 0.26, 1.3, 3.9, 9, 11, 12.75 }, null, { 0.28, 1.5, 4.5, 10, 12, 14 } };
    private Color[]           colors             = { null, Color.CYAN, null, Color.CYAN, Color.CYAN,
        null, Color.MAGENTA, null, Color.MAGENTA, Color.MAGENTA, null, Color.RED, null, Color.RED,
        Color.RED, null, Color.GREEN, Color.GREEN, null, Color.GREEN };

    // CC = Community Chest

    private String[]          chanceCards        = { "Advance to Go",
        "Advance to Illinois Ave. If you pass Go collect 2M. If unowned, you may buy it. If not, pay regular rent",
        "Advance to Kentucky Avenue. If you pass Go, collect 2M. If unowned, you may buy it. If not, pay regular rent",
        "Advance token to Virginia Avenue. If unowned, you may buy it from the Bank. If owned, pay the owner twice the rent",
        "Advance to State Avenue. If unowned, you may buy it from the Bank. If owned, pay owner twice the rental to which they are otherwise entitled. If it is unowned, you may buy it from the Bank.",
        "Bank pays you dividend of 500k", "Go Back Three Spaces.", "Go to Jail",
        "Pay poor tax of 1M", "Take a walk by the beach on Pacific Avenue" };
    private String[]          ccCards            =
        { "Advance to Go", "Bank error in your favor. Collect 200k", "Doctor's fees. Pay 500k",
            "From sale of stock you get 500k", "Grand Opera Night Collect 500k .",
            "Holiday Fund matures. Receive 100k", "Income tax refund. Collect 200k",
            "Life insurance matures. Collect 100k", "Charity donations. Pay 500k",
            "School fees. Pay 100k" };

    /**
     * Creates a new Decks object. Creates the three decks as well.
     */
    public Decks()
    {
        int empty = 0;
        Cards card = null; // initialized to remove error
        chanceDeck = new LinkedList<Cards>();
        while (empty < 10)
        {
            int i = (int)(Math.random() * chanceCards.length);
            if (chanceCards[i] != null)
            {
                if (i == 0)
                    card = new Cards(chanceCards[0], 0, 0);
                else if (i == 1)
                    card = new Cards(chanceCards[1], 0, 14);
                else if (i == 2)
                    card = new Cards(chanceCards[2], 0, 11);
                else if (i == 3)
                    card = new Cards(chanceCards[3], 0, 9);
                else if (i == 4)
                    card = new Cards(chanceCards[4], 0, 8);
                else if (i == 5)
                    card = new Cards(-0.5, chanceCards[5]);
                else if (i == 6)
                    card = new Cards(chanceCards[6], -3, -1);
                else if (i == 7)
                    card = new Cards(chanceCards[7], 0, 5);
                else if (i == 8)
                    card = new Cards(1, chanceCards[8]);
                else if (i == 9)
                    card = new Cards(chanceCards[9], 0, 16);
                chanceDeck.add(card);
                chanceCards[i] = null;
                empty++;
            }
        }

        card = null;
        empty = 0;
        ccDeck = new LinkedList<Cards>();
        while (empty < 10)
        {
            int i = (int)(Math.random() * ccCards.length);
            if (ccCards[i] != null)
            {
                if (i == 0)
                    card = new Cards(ccCards[0], 0, 0);
                else if (i == 1)
                    card = new Cards(-0.2, ccCards[1]);
                else if (i == 2)
                    card = new Cards(0.5, ccCards[2]);
                else if (i == 3)
                    card = new Cards(-0.5, ccCards[3]);
                else if (i == 4)
                    card = new Cards(-0.5, ccCards[4]);
                else if (i == 5)
                    card = new Cards(-0.1, ccCards[5]);
                else if (i == 6)
                    card = new Cards(-0.2, ccCards[6]);
                else if (i == 7)
                    card = new Cards(-0.1, ccCards[7]);
                else if (i == 8)
                    card = new Cards(0.5, ccCards[8]);
                else if (i == 9)
                    card = new Cards(0.1, ccCards[9]);
                ccDeck.add(card);
                ccCards[i] = null;
                empty++;
            }
        }
    }


    /**
     * Draws either a chance or community chest card, returns it, then puts it
     * on the bottom.
     *
     * @param type
     *            of card, either "cc" for community chest, or other for chance
     * @return a Card object
     */
    public Cards draw(String type)
    {
        if (type.equals("cc"))
        {
            Cards card = ccDeck.remove();
            ccDeck.add(card);
            return card;
        }
        Cards card = chanceDeck.remove();
        chanceDeck.add(card);
        return card;
    }


    /**
     * makes the properties.
     */
    public void makeProperties()
    {
        for (int i = 0; i < 19; i++)
        {
            if (propertyPriceLists[i] == null)
            {
                if (i == 0 || i == 5 || i == 10)
                {
                    properties[i] = new PropertyCard(propertyNames[i], "free");
                }
                else if (i == 2 || i == 12)
                {
                    properties[i] = new PropertyCard(propertyNames[i], "Community Chest");
                }
                else if (i == 7 || i == 18)
                {
                    properties[i] = new PropertyCard(propertyNames[i], "Chance");
                }
                else if (i == 15)
                {
                    properties[i] = new PropertyCard(propertyNames[i], "GoToJail");
                }

            }
            else
            {
                properties[i] = new PropertyCard(
                    colors[i],
                    propertyNames[i],
                    propertyPrices[i],
                    propertyPriceLists[i]);
            }
        }
    }


    /**
     * Returns the PropertyCard array of properties
     *
     * @return the properties
     */
    public PropertyCard[] getProperties()
    {
        return properties;
    }

}
