package files;

/**
 * Conducts and handles transactions between Players and the bank
 *
 * @author ojasgupta
 * @version May 11, 2021
 */
public class Transaction
{
    // ~ Fields ................................................................
    private double        waitFactor;
    private MessageCenter messages;

    // ~ Constructors ..........................................................
    /**
     * Creates a new Transaction object. WaitFactor parameter is for delay
     *
     * @param a
     *            wait factor
     * @param b
     *            message center
     */
    public Transaction(double a, MessageCenter b)
    {
        waitFactor = a;
        messages = b;
    }


    // ~Public Methods ........................................................
    /**
     * represents a paying bank method. Amount can be negative to represent
     * getting paid.
     *
     * @param a
     *            Player getting paid
     * @param amount
     *            amount to be paid
     * @param action
     *            why paying bank
     */
    public void payBank(Player a, double amount, String action)
    {
        try
        {
            Thread.sleep((int)(1000.0 * waitFactor));
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
        a.addMoney(-amount);
        if (amount >= 0)
        {
            messages.paidBank(a.getName(), amount, action);
        }
        else
        {
            messages.bankPaid(a.getName(), -amount, action);
        }
    }


    /**
     * Represents a transaction between players.
     *
     * @param toPay
     *            whose paying
     * @param beingPaid
     *            whose being paid
     * @param amount
     *            amount being paid (mil)
     * @param action
     *            why they are paying (for message center)
     */
    public void payPlayer(Player toPay, Player beingPaid, double amount, String action)
    {
        try
        {
            Thread.sleep((int)(1000.0 * waitFactor));
        }
        catch (InterruptedException e)
        {
        }
        toPay.addMoney(-amount);
        if (beingPaid != null) beingPaid.addMoney(amount);
        messages.owedMoney(toPay.getName(), beingPaid.getName(), amount, action);
    }

}
