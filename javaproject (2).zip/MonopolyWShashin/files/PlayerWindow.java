package files;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

/**
 * A GUI designed to take the requests of a player for the HumanPlayer class.
 * Has all of the buttons and a small JTextArea.
 *
 * @author ojasgupta
 * @version May 17, 2021
 */
public class PlayerWindow
    extends JFrame
    implements ActionListener
{
    private HumanPlayer        player;
    private JTextArea          original;
    private JButton            go;
    private JButton            buy;
    private JButton            pass;
    private JButton            pay;
    private JButton            mortgage;
    private JButton            giveUp;
    private JButton            unmortgage;
    private JButton            doneTurn;
    private ArrayList<JButton> mortgages;
    private ArrayList<JButton> mortgaged;
    private ArrayList<JButton> houses;
    private boolean            jailTurn;
    private boolean            mustMortgage;
    private double             amountToPay;
    private String             defaultMessage;
    private Box                box1;

    /**
     * Creates a new PlayerWindow object. calls a helper method to set up GUI
     *
     * @param a
     *            The HumanPlayer this object is associated with
     */
    public PlayerWindow(HumanPlayer a)
    {
        super(a.getName() + "'s action panel");
        player = a;
        defaultMessage = "It is now your turn, " + player.getName()
            + "! Start by rolling the die, and any additional options (buy, build, etc.) will show up beneath. "
            + "\nTransactions will be completed automatically!";
        player = a;
        box1 = Box.createVerticalBox();
        setUpGUI();
        mortgages = new ArrayList<JButton>();
        mortgaged = new ArrayList<JButton>();
        houses = new ArrayList<JButton>();
    }


    /**
     * Private helper method to help set up GUI.
     */
    private void setUpGUI()
    {
        original = new JTextArea(5, 30);
        original.setLineWrap(true);
        original.setWrapStyleWord(true);
        original.setEditable(false);
        JScrollPane originalPane = new JScrollPane(
            original,
            ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
            ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        original.setText(defaultMessage);
        go = new JButton("Click to roll the die");
        go.setAlignmentX(Component.CENTER_ALIGNMENT);
        go.addActionListener(this);
        go.setVisible(false);
        buy = new JButton("Click to buy it!");
        buy.setAlignmentX(Component.LEFT_ALIGNMENT);
        buy.addActionListener(this);
        buy.setVisible(false);
        pass = new JButton("Click to not buy");
        pass.setAlignmentX(Component.RIGHT_ALIGNMENT);
        pass.addActionListener(this);
        pass.setVisible(false);
        mortgage = new JButton("Click to mortgage a property!");
        mortgage.setAlignmentX(Component.CENTER_ALIGNMENT);
        mortgage.addActionListener(this);
        mortgage.setVisible(false);
        pay = new JButton("Click to pay 500k and get out of jail");
        pay.setAlignmentX(Component.CENTER_ALIGNMENT);
        pay.addActionListener(this);
        pay.setVisible(false);
        unmortgage = new JButton("Click to unmortgage");
        unmortgage.setAlignmentX(Component.CENTER_ALIGNMENT);
        unmortgage.addActionListener(this);
        unmortgage.setVisible(false);
        giveUp = new JButton("Click to give up :(");
        giveUp.setAlignmentX(Component.CENTER_ALIGNMENT);
        giveUp.addActionListener(this);
        giveUp.setVisible(false);
        doneTurn = new JButton("Click to end your turn");
        doneTurn.setAlignmentX(Component.CENTER_ALIGNMENT);
        doneTurn.addActionListener(this);
        doneTurn.setVisible(false);
        box1.add(originalPane);
        box1.add(Box.createVerticalStrut(10));
        box1.add(go);
        box1.add(buy);
        box1.add(pass);
        box1.add(pay);
        box1.add(mortgage);
        box1.add(giveUp);
        box1.add(unmortgage);
        Container c = getContentPane();
        c.setLayout(new FlowLayout());
        c.add(box1);
        original.setText(
            "Do not close this, " + player.getName()
                + "! Your actions will show up here on your turn");
        setVisible(true);
        setSize(600, 700);
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource() == go)
        {
            go.setVisible(false);
            pay.setVisible(false);
            doneTurn.setVisible(true);
            if (!jailTurn)
            {
                player.doTurn();
            }
            else
            {
                player.doJailTurn();
            }
        }
        if (e.getSource() == pass)
        {
            player.houses();
            pass.setVisible(false);
            buy.setVisible(false);
        }
        if (e.getSource() == buy)
        {
            if (player.canPay(player.newProperty().getPropertyValue()) == 0)
            {
                player.bought();
                pass.setVisible(false);
                buy.setVisible(false);
            }
            else if (player.canPay(player.newProperty().getPropertyValue()) == 1)
            {
                original.setText("You need to mortgage more if you want to buy!" + '\n');
            }
        }
        if (e.getSource() == pay)
        {
            go.setVisible(false);
            pay.setVisible(false);
            player.payJail();
        }
        if (e.getSource() == giveUp)
        {
            player.giveUp();
            return;
        }
        if (e.getSource() == doneTurn)
        {
            player.turnDone();
        }
        if (mortgages.contains(e.getSource()))
        {
            JButton processor = ((JButton)e.getSource());
            String c = (processor).getName();
            for (int i = 0; i < player.getProperties().size(); i++)
            {
                PropertyCard processing = player.getProperties().get(i);
                if (processing.getName().equals(c))
                {
                    System.out.println("made it!");
                    if (processing.getHouseInfo()[1] == 0)
                    {
                        mortgages.remove(mortgages.indexOf(processor));
                        processor.setVisible(false);
                        processing.setMortgage(true);
                        player.mortgage(processing, false);
                    }
                    else
                    {
                        player.mortgage(processing, true);
                    }
                }
            }
        }
        if (mortgaged.contains(e.getSource()))
        {
            JButton processor = ((JButton)e.getSource());
            String c = (processor).getName();
            for (int i = 0; i < player.getProperties().size(); i++)
            {
                PropertyCard processing = player.getProperties().get(i);
                if (processing.getName().equals(c))
                {
                    if (player.canPay(processing.getPropertyValue()) == 0)
                    {
                        processor.setVisible(false);
                        mortgaged.remove(mortgaged.indexOf(processor));
                        processing.setMortgage(false);
                        player.unmortgage(processing);
                    }
                    else
                    {
                        original.setText("You don't have enough money! " + '\n' + defaultMessage);
                    }
                }
            }
        }
        if (houses != null && houses.contains(e.getSource()))
        {
            JButton processor = ((JButton)e.getSource());
            String c = (processor).getName();
            for (int i = 0; i < player.getProperties().size(); i++)
            {
                PropertyCard processing = player.getProperties().get(i);
                if (processing.getName().equals(c))
                {
                    if (player.canPay(processing.getHouseInfo()[0]) == 0
                        && processing.getHouseInfo()[1] != 5)
                    {
                        player.buildHouse(processing);
                    }
                    else
                    {
                        original.setText(
                            "You don't have enough money or have already built the max amount of houses! "
                                + '\n' + defaultMessage);
                    }
                }
            }
        }
        if (e.getSource() == unmortgage)
        {
            unmortgage.setVisible(false);
            if (mortgaged.size() == 0)
            {
                original.setText("You can't unmortgage anything! " + '\n' + defaultMessage);
            }
            else
            {
                original.setText(
                    "Click on a button to unmortgage that property. The mortgage value is the price"
                        + " of the property divided by two times 1.1.");
                Unmortgageable();
                return;

            }
        }
        if (e.getSource() == mortgage)
        {
            if (player.getProperties().isEmpty())
            {
                original.setText("You can't mortgage anything! " + '\n' + defaultMessage);
                return;
            }
            else if (!mustMortgage)
            {
                mortgage.setVisible(false);
                original.setText(
                    "Click on a button to mortgage that property. The mortgage value is the price"
                        + " of the property divided by two. Clicking mortgage for a property with a house on it "
                        + "will first sell the house, one house per click, for half the building cost. Click 'pass' "
                        + "when you are finished.");
                pass.setVisible(true);
                Mortgageable();
                return;
            }
            else
            {
                mortgage.setVisible(false);
                original.setText(
                    "Click on a button to mortgage that property. The mortgage value is the price of the "
                        + "property divided by two. You must pay " + amountToPay
                        + " million. Clicking mortgage for a property with a house on it will first sell the house, "
                        + "one house per click, for half the building cost. There is a give up button if you "
                        + "can't/don't think you can hit the required amount");
                giveUp.setVisible(true);
                Mortgageable();
                return;
            }
        }
    }


    /**
     * Is called at the beginning of a turn. Sets the "roll Die" and "mortgage"
     * buttons visible.
     */
    public void goTime()
    {
        go.setVisible(true);
        mortgage.setVisible(true);
        original.setText(defaultMessage);
        original.setVisible(true);
        if (mortgaged.size() > 0)
        {
            unmortgage.setVisible(true);
        }
        return;
    }


    /**
     * Is called at the beginning of a jail turn. the roll die button and the
     * pay to get out of jail button are visible.
     */
    public void goJailTime()
    {
        go.setVisible(true);
        pay.setVisible(true);
        original.setText("Its your turn, but remember, you are in jail!");
        jailTurn = true;
        return;
    }


    /**
     * Is called when a player lands on an unowned property. Sets the "buy" and
     * "pass" buttons to visible.
     */
    public void buyTime()
    {
        buy.setVisible(true);
        pass.setVisible(true);
        return;
    }


    /**
     * All the other buttons become visible/invisible only of the option to use
     * it arises. The mortgages/unmortgages button becomes visible and
     * disappears at the beginning and end of every turn. This method controls
     * the disappearing at the end
     */
    public void turnDone()
    {
        mortgage.setVisible(false);
        unmortgage.setVisible(false);
        original.setText(
            "Do not close this, " + player.getName()
                + "! Your actions will show up here on your turn");
        for (int i = 0; i < mortgaged.size(); i++)
        {
            mortgaged.get(i).setVisible(false);
        }
        for (int i = 0; i < mortgages.size(); i++)
        {
            mortgages.get(i).setVisible(false);
        }
        if (houses != null)
        {
            for (int i = 0; i < houses.size(); i++)
            {
                houses.get(i).setVisible(false);
            }
        }
    }


    /**
     * Sets the amount needed to be paid. Used for mortgaging process. Also sets
     * up the stage when mortgaging is the only thing that is available
     *
     * @param mil
     *            amount to be paid
     */
    public void setPayAmount(double mil)
    {
        amountToPay = mil;
        mustMortgage = true;
        go.setVisible(false);
        buy.setVisible(false);
        pass.setVisible(false);
        pay.setVisible(false);
        unmortgage.setVisible(false);
    }


    /**
     * Sets up the unmortgaging buttons for all the properties that are
     * unmortgageable.
     */
    public void Unmortgageable()
    {
        mortgaged.clear();
        int i = 0;
        for (PropertyCard a : player.getProperties())
        {
            if (!a.isMortgaged())
            {
                JButton b = new JButton(a.getName());
                mortgaged.add(b);
                if (i % 3 == 0)
                    b.setAlignmentX(Component.CENTER_ALIGNMENT);
                else if (i % 3 == 1)
                    b.setAlignmentX(Component.LEFT_ALIGNMENT);
                else
                    b.setAlignmentX(Component.RIGHT_ALIGNMENT);
                b.addActionListener(this);
                b.setVisible(true);
                box1.add(b);
                i++;

            }
        }
    }


    /**
     * Creates buttons for all the properties that are mortgageable.
     */
    public void Mortgageable()
    {
        mortgages.clear();
        int i = 0;
        for (PropertyCard a : player.getProperties())
        {
            if (!a.isMortgaged())
            {
                JButton b = new JButton(a.getName());
                mortgages.add(b);
                if (i % 3 == 0)
                    b.setAlignmentX(Component.CENTER_ALIGNMENT);
                else if (i % 3 == 1)
                    b.setAlignmentX(Component.LEFT_ALIGNMENT);
                else
                    b.setAlignmentX(Component.RIGHT_ALIGNMENT);
                b.addActionListener(this);
                b.setVisible(true);
                box1.add(b);
                i++;

            }
        }
    }


    /**
     * Creates buttons for all the properties that houses can be built on.
     *
     * @param spots
     *            arrayList of property cards to test
     */
    public void houseTime(ArrayList<PropertyCard> spots)
    {
        pass.setVisible(true);
        if (houses.size() > 0)
        {
            houses.clear();
        }
        int i = 0;
        for (int j = 0; j < spots.size(); j++)
        {
            if (0 == player.canPay(spots.get(i).getHouseInfo()[0]))
            {
                JButton b = new JButton(spots.get(i).getName());
                houses.add(b);
                if (i % 3 == 0)
                    b.setAlignmentX(Component.CENTER_ALIGNMENT);
                else if (i % 3 == 1)
                    b.setAlignmentX(Component.LEFT_ALIGNMENT);
                else
                    b.setAlignmentX(Component.RIGHT_ALIGNMENT);
                b.addActionListener(this);
                b.setVisible(true);
                box1.add(b);
                i++;
            }
        }
    }

/*
 * public static void main(String[] args) { HumanPlayer a = new HumanPlayer( new
 * DieRoll(), new DieRoll(), new PropertyCard[3], "name", new GameRunner(),
 * 4.0); PlayerWindow test = new PlayerWindow(a); test.setBounds(100, 100, 480,
 * 480); test.setDefaultCloseOperation(EXIT_ON_CLOSE); test.setVisible(true); }
 */
}
