package files;

import java.util.ArrayList;
import java.awt.*;

/**
 * most methods are abstract and are implemented by the respective HumanPlayer
 * or ComputerPlayer classes, because one requires manual input of the human
 * player and the other doesn’t. Some classes, such as what to do with a chance
 * card and calling the transaction class for transactions, are implemented for
 * efficiency. Stores a online “map” of the properties/spaces so it doesn’t need
 * to work with the Board class to determine which space the player is currently
 * on.
 *
 * @author ojasgupta
 * @version May 11, 2021
 */
public abstract class Player
{
    private double                  moneyMil;
    private DieRoll                 dice1;
    private DieRoll                 dice2;
    private int                     currentPos;
    private PropertyCard[]          properties;
    private ArrayList<PropertyCard> propertiesOwned;
    private boolean                 rollAgain;
    private String                  name;
    private GameRunner              GR;
    private int                     jailCount;
    private PlayerPiece             piece;
    private String color;
    /**
     * The rate at which transactions, die rolls, moving players, etc. are to
     * process at
     */
    public double                   transactionFactor;

    /**
     * Creates a new Player object. Starting money is default 15 mil.
     *
     * @param a
     *            Die1 roll to work with
     * @param b
     *            Die2 roll to work with
     * @param s
     *            Property card array
     * @param z
     *            name of player
     * @param color
     *            color of player piece (single lettered string)
     * @param factor
     *            transaction factor
     * @param x
     *            name of GameRunner
     */
    public Player(
        DieRoll a,
        DieRoll b,
        PropertyCard[] s,
        String z,
        GameRunner x,
        String color,
        double factor)
    {
        moneyMil = 15.0;
        dice1 = a;
        dice2 = b;
        currentPos = 0;
        properties = s;
        rollAgain = false;
        name = z;
        GR = x;
        propertiesOwned = new ArrayList<PropertyCard>();
        jailCount = 0;
        transactionFactor = factor;
        piece = new PlayerPiece(color, transactionFactor, this);
        this.color = color;
    }

    public String getColor()
    {
        return color.toLowerCase();
    }

    /**
     * Creates a new Player object. Starting money is now a parameter
     *
     * @param a
     *            money to start with (in millions)
     * @param b
     *            Die roll1 to work with
     * @param c
     *            Die roll 2 to work with
     * @param s
     *            Property card array
     * @param z
     *            name of player
     * @param color
     *            color of player piece
     * @param factor
     *            transactionfactor
     * @param x
     *            name of GameRunner
     */
    public Player(
        double a,
        DieRoll b,
        DieRoll c,
        PropertyCard[] s,
        String z,
        GameRunner x,
        String color,
        double factor)
    {
        moneyMil = a;
        dice1 = b;
        dice2 = c;
        currentPos = 0;
        properties = s;
        rollAgain = false;
        name = z;
        GR = x;
        propertiesOwned = new ArrayList<PropertyCard>();
        jailCount = 0;
        transactionFactor = factor;
        piece = new PlayerPiece(color, transactionFactor, this);
    }


    // ~Public Methods ........................................................
    /**
     * Called by the Game Runner class, sets up the rest of the classes.
     */
    public abstract void takeTurn();


    /**
     * Called by the Game Runner class as an alternative to the TakeTurn
     * depending on if the player is in jail.
     */
    public abstract void takeJailTurn();


    /**
     * returns the transaction factor to determine speed of transactions.
     *
     * @return double transaction factor
     */
    public abstract double getFactor();


    /**
     * Sets up the turn after a chance card moves the player
     */
    public abstract void TurnAfterChanceMoved();


    /**
     * handles the house building process.
     */
    public abstract void houses();


    /**
     * Returns the player piece associated by this player.
     *
     * @return PlayerPiece piece owned
     */
    public PlayerPiece getPlayerPiece()
    {
        return piece;
    }
    // TODO call by gameRunner


    /**
     * Sets factor.
     *
     * @param x
     *            new factor
     */
    public void setFactor(double x)
    {
        transactionFactor = x;
    }


    /**
     * Method to collect 2 mil when go is passed. Called by player piece.
     */
    public void passGo()
    {
        Transaction b = new Transaction(transactionFactor, Messages());
        String phrase = "go";
        b.payBank(this, -2.0, phrase);
    }


    /**
     * Rolls the die and calls the GameRunner for graphics.
     *
     * @return an array with the values. An array is needed so classes that call
     *         this method can test for doubles
     */

    public int[] rollTheDie()
    {
        GR.rollDice();
        int a = dice1.getRoll();
        int b = dice2.getRoll();
        return new int[] { a, b };
    }


    /**
     * Sets the position of a player
     *
     * @param pos
     *            new position
     */
    public void setPosition(int pos)
    {
        currentPos = pos;
        piece.moveTo(pos, true);
    }


    /**
     * Puts player in jail.
     */
    public void goToJail()
    {
        currentPos = 11;
        piece.moveTo(11, false);
        GR.moveToJail(getName());
    }


    /**
     * gets the position of a player.
     *
     * @return current position
     */
    public int getPosition()
    {
        return currentPos;
    }


    /**
     * REturns the gameRunner for extended classes to use.
     *
     * @return GameRunner
     */
    public GameRunner getGameRunner()
    {
        return GR;
    }


    /**
     * Called by subclasses to return the current property based on die. Also
     * handles double rolling
     *
     * @param a
     *            the first die roll
     * @param b
     *            the second die roll
     * @return current property card
     */
    public PropertyCard diceAnalysis(int a, int b)
    {
        if (a == b)
        {
            rollAgain = true;
            jailCount++;
        }
        else
        {
            jailCount = 0;
            rollAgain = false;
        }
        currentPos += a;
        currentPos += b;
        currentPos = currentPos % 20;
        piece.move(a + b, true);
        return properties[currentPos];
    }


    /**
     * Returns the money in the bank account.
     *
     * @return double money in millions
     */
    public double getMoney()
    {
        return moneyMil;
    }


    /**
     * Adds a specified amount of money. negative parameter for subtraction
     *
     * @param a
     *            amount to add
     */
    public void addMoney(double a)
    {
        moneyMil += a;
    }


    /**
     * Sets the money in millions to a number.
     *
     * @param a
     *            new bank account value
     */
    public void setMoney(double a)
    {
        moneyMil = a;
    }


    /**
     * returns name of player.
     *
     * @return String name
     */
    public String getName()
    {
        return name;
    }


    /**
     * Gets the new property after a position change.
     *
     * @return new propertycard
     */
    public PropertyCard newProperty()
    {
        return properties[currentPos];
    }


    /**
     * Returns the owned properties.
     *
     * @return ArrayList of property owned cards
     */
    public ArrayList<PropertyCard> getProperties()
    {
        return propertiesOwned;
    }


    /**
     * adds a property to the properties owned arrayList. Keeps items in order
     * of propertyvalue
     *
     * @param a
     *            property to add
     */
    public void addProperty(PropertyCard a)
    {
        if (propertiesOwned.size() == 0)
        {
            propertiesOwned.add(a);
        }
        else
        {
            for (int i = 0; i < propertiesOwned.size(); i++)
            {
                if (propertiesOwned.get(i).getPropertyValue() > a.getPropertyValue())
                {
                    propertiesOwned.add(i, a);
                    return;
                }
            }
        }
        propertiesOwned.add(a);
    }


    /**
     * Resets the status of a property card. Sets it as unowned and calls the
     * reset method of the card
     *
     * @param a
     *            propertyCard to reset
     */
    public void returnProperty(PropertyCard a)
    {
        propertiesOwned.remove(a);
        a.reset();
    }


    /**
     * Returns the message center associated with this player class.
     *
     * @return messages
     */
    public MessageCenter Messages()
    {
        return GR.messageCenter();
    }


    /**
     * Called by the GameRunner Class to determine if a player neds to roll
     * again.
     *
     * @return 0 if not, 1 if roll again, 2 if roll again but now in jail
     */
    // TODO call by GR
    public int rollAgain()
    {
        if (rollAgain == true && jailCount > 3)
        {
            return 1;
        }
        if (rollAgain == true && jailCount == 3)
        {
            return 2;
        }
        return 0;
    }


    /**
     * Sends a message to the GameRunner that this player gives Up, and is
     * bankrupted.
     */
    public void giveUp()
    {
        int i = 0;
        while (i < propertiesOwned.size())
        {
            returnProperty(propertiesOwned.get(i));
        }
        GR.bankrupt(getName());
    }


    /**
     * Determines if a player can pay a certain amount.
     *
     * @param price
     *            amount to pay
     * @return 0 if can pay, 1 if mortgaging is needed, 2 if not
     */
    public int canPay(double price)
    {
        if (moneyMil >= price)
        {
            return 0;
        }
        if (moneyMil < price && propertiesOwned.size() == 0)
        {
            return 2;
        }
        int mortgage = 0;
        for (int i = 0; i < propertiesOwned.size(); i++)
        {
            mortgage += propertiesOwned.get(i).getPropertyValue() / 2.0;
        }
        if (moneyMil + mortgage >= price)
        {
            return 0;
        }
        return 1;
    }


    /**
     * Determines if a player can build houses.
     *
     * @return ArrayList of propertyCards where a player can build houses
     */
    public ArrayList<PropertyCard> canBuild()
    {
        /*
         * ArrayList<ArrayList<PropertyCard>> intermediate = new
         * ArrayList<ArrayList<PropertyCard>>(); ArrayList<Color> checked = new
         * ArrayList<Color>(); for (PropertyCard card : propertiesOwned) { if
         * (checked.size() == 0 || !checked.contains(card.getColor())) {
         * intermediate.add(canBuildHelper(card)); checked.add(card.getColor());
         * } } ArrayList<PropertyCard> toReturn = new ArrayList<PropertyCard>();
         * for (ArrayList<PropertyCard> colors : intermediate) { if
         * (colors.size() == 3) { toReturn.add(colors.get(1));
         * toReturn.add(colors.get(2)); toReturn.add(colors.get(3)); } }
         */
        ArrayList<PropertyCard> toReturn = new ArrayList<PropertyCard>();
        int sameCount = 1;
        ArrayList<PropertyCard> possProps = new ArrayList<PropertyCard>();
        for (int i = 0; i < propertiesOwned.size(); i++)
        {
            if (propertiesOwned.get(i).getColor() != null)
            {
                possProps.add(propertiesOwned.get(i));
            }
        }
        for (int i = 1; i < possProps.size(); i++)
        {
            Color current = possProps.get(i).getColor();
            if (current.equals(possProps.get(i - 1).getColor()))
            {
                sameCount++;
            }
            else
            {
                sameCount = 1;
            }
            if ((sameCount == 3 && (!current.equals(Color.GRAY) || !current.equals(Color.BLUE))))
            {
                toReturn.add(possProps.get(i - 2));
                toReturn.add(possProps.get(i - 1));
                toReturn.add(possProps.get(i));
            }
            else if (sameCount == 2 && (current.equals(Color.GRAY) || current.equals(Color.BLUE)))
            {
                toReturn.add(possProps.get(i - 1));
                toReturn.add(possProps.get(i));
            }

        }
        return toReturn;
    }

/*
 * /** Helper method to determine if this needs to be added to the processing
 * ArrayList in the canBuild method.
 * @param card card to check
 * @return an ArrayList with the other PropertyCards that have the same color
 **/
    /*
     * private ArrayList<PropertyCard> canBuildHelper(PropertyCard card) {
     * ArrayList<PropertyCard> toReturn = new ArrayList<PropertyCard>(); Color
     * color = card.getColor(); for (PropertyCard test : propertiesOwned) { if
     * (test.getColor().equals(color) && !test.isMortgaged()) {
     * toReturn.add(test); } } return toReturn; }
     */

}
