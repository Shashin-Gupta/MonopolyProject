package files;

import java.awt.*;

/**
 * Handles the software “info” of the card: Color of property/group it belongs
 * to, price to buy, rent price, associated rent prices with house(s) or a
 * hotel.
 *
 * @author ojasgupta
 * @version May 11, 2021
 */
public class PropertyCard
{

    private double   propertyValue;
    private boolean  mortgaged;
    private Color    color;
    private Player   owner;
    private String   propertyName;
    private int      houseCount = 0;
    private double   costForHouse;
    private double[] priceList;
    private String   type;
    private int owned;

    /**
     * Creates a new PropertyCard object.
     *
     * @param color
     *            color group of the property
     * @param propertyName
     *            name of the property
     * @param PropertyValue
     *            Cost to buy property from bank
     * @param priceList
     *            array representing how much rent is due for 0, 1, 2, 3, 4, and
     *            5 houses (5th house considered the hotel)
     */
    public PropertyCard(Color color, String propertyName, double PropertyValue, double[] priceList)
    {
        this.color = color;
        this.propertyName = propertyName;
        this.propertyValue = PropertyValue;
        this.priceList = priceList;
        owner = null;
        owned = 0;
        houseCount = 0;
        if (color == null)
        {
            this.color = null;
        }
        else
        {
            if (color.equals(Color.GRAY) || color.equals(Color.CYAN))
            {
                this.costForHouse = 0.5;
            }
            else if (color.equals(Color.MAGENTA) || color.equals(Color.ORANGE))
            {
                this.costForHouse = 1;
            }
            else if (color.equals(Color.RED) || color.equals(Color.YELLOW))
            {
                this.costForHouse = 1.5;
            }
            else
            {
                this.costForHouse = 2;
            }
        }
    }


    /**
     * Creates a new PropertyCard object.
     *
     * @param name
     *            name of property
     * @param type
     *            type of property. This is for easier processing by the player
     *            class as some squares (ex: free parking, chance cards) have
     *            different functions
     */
    public PropertyCard(String name, String type)
    {
        propertyName = name;
        this.type = type;
        owner = null;
    }


    /**
     * Resets the modifications done by a player, such as when they go bankrupt
     */
    public void reset()
    {
        owner = null;
        houseCount = 0;
        mortgaged = false;
        owned = 0;
    }


    /**
     * Method that calculates the .
     *
     * @return double how much rent is due
     */
    public double getRent()
    {
        return priceList[houseCount];
    }


    /**
     * REturns the type of property for easier processing by player class.
     *
     * @return String type of property
     */
    public String getType()
    {
        return type;
    }


    /**
     * Returns the cost to build each house and the number of houses.
     *
     * @return array with doubles representing the above two variables.
     *         houseCount is cast into a double even though it is an int
     */
    public double[] getHouseInfo()
    {
        double[] toReturn = { costForHouse, houseCount };
        return toReturn;

    }


    /**
     * Builds a house.
     */
    public void addHouse()
    {
        houseCount++;
    }


/*
 * public boolean trigger(Player player){ return null; }
 */
    /**
     * Gets the owner of the property
     *
     * @return Player who is owner
     */
    public Player getOwner()
    {
        return owner;
    }


    /**
     * Returns a boolean if this property is owned.
     *
     * @return true if owned
     */
    public boolean isOwned()
    {
        return owned == 0;
    }


    /**
     * Sets the owner of the property
     *
     * @param play
     */
    public void setOwner(Player play)
    {
        owner = play;
        owned++;
    }


    /**
     * Gets the mortgaged status of the property
     *
     * @return boolean true if mortgaged
     */
    public boolean isMortgaged()
    {
        return mortgaged;
    }


    /**
     * SEts the mortgage status of a property.
     *
     * @param bool
     *            what to set the mortgagae status to.
     */
    public void setMortgage(boolean bool)
    {
        mortgaged = bool;
    }


    /**
     * Place a description of your method here.
     *
     * @return Property name
     */
    public String getName()
    {
        return propertyName;
    }


    /**
     * Gets the property value
     *
     * @return cost to buy this house
     */
    public double getPropertyValue()
    {
        return propertyValue;
    }


    /**
     * Gets the color group this property belongs to
     *
     * @return Color group
     */
    public Color getColor()
    {
        return color;
    }


    public String toString()
    {
        String status = "";

        if (isMortgaged())
            // will show if property is mortgaged
            status += " (Mortgaged)";

        return super.toString() + status;
    }

}
