package files;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;

/**
 * is assigned to a Player object, and works with the DieRoll class to find out
 * how many spaces it needs to move. Uses the distances in the Board class to
 * move one space and calculates when it turns. .
 *
 * @author ojasgupta
 * @version May 21, 2021
 */
public class PlayerPiece
    extends JPanel
{
    // ~ Fields ................................................................
    private static int characterNum = 1;
    private static int tileSpace    = 100;
    private static int diamOfPiece  = 25;
    private int        xLeft;
    private int        yTop;
    private Color      color;
    private int        currentPos;
    private double     speed;
    private Player     player;
    private int        characterOrder;

    // ~ Constructors ..........................................................
    /**
     * Creates a new PlayerPiece object with the respective parameters
     *
     * @param a
     *            String for color
     * @param speed
     *            speed of the piece (for wait times)
     * @param player
     *            to be associated with
     */
    public PlayerPiece(String a, double speed, Player player)
    {
        xLeft = -1;
        yTop = -1;
        currentPos = 0;
        this.speed = speed;
        this.player = player;
        if (a.equalsIgnoreCase("b"))
        {
            color = Color.BLUE;
        }
        else if (a.equalsIgnoreCase("g"))
        {
            color = Color.GREEN;
        }
        else if (a.equalsIgnoreCase("o"))
        {
            color = Color.ORANGE;
        }
        else
        {
            color = Color.RED;
        }
    }


    // ~Public Methods ........................................................
    /**
     * Initializes a player piece
     *
     * @param a
     *            graphics
     */
    public void initialize()
    {
        xLeft = 10 + diamOfPiece * characterNum;
        yTop = 10;
        characterOrder = characterNum;
        characterNum++;
        repaint();
    }


    /**
     * Moves a player piece given amount of spaces.
     *
     * @param numOfSpaces
     *            integer number of spaces to be moved
     * @param b
     *            true or false representing if they should collect 2 mil for
     *            passing go
     */
    public void move(int numOfSpaces, boolean b)
    {
        int spotsMoved = 0;
        while (spotsMoved < numOfSpaces)
        {
            if (currentPos == 20)
                movePastGo(b);
            else if (currentPos % 5 == 0)
            {
                moveResetPos();
            }
            else
            {
                move();
            }
            spotsMoved++;
            currentPos++;
        }
    }


    /**
     * Moves to a certain index.
     *
     * @param index
     *            to move to
     * @param b
     *            true or false on if they should collect 2 mil
     */
    public void moveTo(int index, boolean b)
    {
        double temp = speed;
        setSpeed(0);
        if (index == 5)
        {
            b = false;
        }
        if (index >= currentPos)
        {
            move(index - currentPos, b);
        }
        else
        {
            move(20 + index - currentPos, b);
        }
        setSpeed(temp);
    }


    /**
     * Sets the speed.
     *
     * @param a
     *            new speed double
     */
    private void setSpeed(double a)
    {
        speed = a;
    }


    /**
     * Handles when a player moves past go with.
     *
     * @param a
     *            boolean on if they should collect 2 mil
     */
    private void movePastGo(boolean a)
    {
        if (a)
        {
            player.passGo();
        }
        currentPos = -1;
        try
        {
            Thread.sleep((int)(400.0 * speed));
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
        yTop += tileSpace;
        yTop += (4 - characterOrder) * tileSpace / 4;
        xLeft -= (characterOrder - 1) * tileSpace / 4;
        repaint();
    }


    /**
     * Handles a regular move that is not on a end square (5, 10, 15, or 20).
     */
    private void move()
    {
        if (currentPos < 10)
        {
            xLeft -= tileSpace;
            repaint();
        }
        else if (currentPos < 20)
        {
            yTop -= tileSpace;
            repaint();
        }
        else if (currentPos < 30)
        {
            xLeft += tileSpace;
            repaint();
        }
        else
        {
            yTop += tileSpace;
            repaint();
        }
    }


    /**
     * Handles a move that is on an end square (5, 10, 15, or 20).
     */
    private void moveResetPos()
    {
        try
        {
            Thread.sleep((int)(400.0 * speed));
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }

        if (currentPos == 10)
        {
            xLeft -= tileSpace;
            xLeft -= (4 - characterOrder) * tileSpace / 4;
            yTop -= (characterOrder - 1) * tileSpace / 4;
            repaint();
        }
        else if (currentPos == 20)
        {
            yTop -= tileSpace;
            yTop -= (4 - characterOrder) * tileSpace / 4;
            xLeft += (characterOrder - 1) * tileSpace / 4;
            repaint();
        }
        else
        {
            xLeft += tileSpace;
            xLeft += (4 - characterOrder) * tileSpace / 4;
            yTop += (characterOrder - 1) * tileSpace / 4;
            repaint();
        }
    }


    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        g.setColor(color);
        g.fillRoundRect(xLeft, yTop, diamOfPiece, diamOfPiece, diamOfPiece / 4, diamOfPiece / 4);
    }
}
