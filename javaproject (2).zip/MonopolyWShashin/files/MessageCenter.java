package files;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

/**
 * The main place where important messages show up. Goes on the main board.
 *
 * @author ojasgupta
 * @version May 11, 2021
 */
public class MessageCenter
    extends JFrame
    implements ActionListener
{
    private JTextArea messages;

    // ~ Constructors ..........................................................
    /**
     * Creates a new MessageCenter object. Calls a helper method to set up the
     * GUI
     */
    public MessageCenter()
    {
        super("Monopoly Messages");

        setupGui();

        messages.append(
            "Important messages will show up here. Each human player should have their "
                + "own panel to make decisions on their turn. If a computer "
                + "player is going first, their turn should begin shortly. Good Luck! \n ");
    }


    /**
     * REturns the JTextArea for graphics by the Game Runner.
     *
     * @return messages
     */
    public JTextArea getMessages()
    {
        return messages;
    }


    /**
     * Helper method to set up the GUI.
     */
    private void setupGui()
    {

        messages = new JTextArea(10, 30);
        messages.setEditable(false);
        // translate.setBackground(Color.LIGHT_GRAY);
        messages.setBackground(new Color(240, 248, 255));
        messages.setLineWrap(true);
        messages.setWrapStyleWord(true);
        JScrollPane markedPane = new JScrollPane(
            messages,
            ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
            ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        messages.append(
            "Hi there! ");
        Box box1 = Box.createVerticalBox();
        box1.add(Box.createVerticalStrut(10));
        box1.add(markedPane);

        Container c = getContentPane();
        c.setLayout(new FlowLayout());
        c.add(box1);
    }

    // ~Public Methods ........................................................


// Methods to display messages after a transaction
    /**
     * Handles when a Player pays the bank. Has conditions for buying a
     * property, following a Card, or getting out of jail
     *
     * @param player
     *            whose doing the action
     * @param amount1
     *            amount to pay
     * @param action
     *            filter for why they are paying. The buy and unmortgage types
     *            contain the property it pertains to after a space
     * @precondition action var must start with "buy", "Community Chest",
     *               "Chance", "jail", "unmortgage", or "house"
     */
    public void paidBank(String player, double amount1, String action)
    {
        if (action != null && action.contains("buy"))
        {
            messages.append(
                player + " just paid the banker " + amount1 + " million to buy "
                    + action.substring(4) + '\n');
        }
        else if (action != null && (action.equals("Community Chest") || action.equals("Chance")))
        {
            messages.append(
                player + " just paid the banker " + amount1 + " million due to the " + action
                    + "card" + '\n');
        }
        else if (action != null && action.equals("jail"))
        {
            messages.append(
                player + " just paid the banker " + amount1 + " million to get out of jail" + '\n');
        }
        else if (action != null && action.equals("unmortgage"))
        {
            messages.append(
                player + " just paid the banker " + amount1 + " million to unmortgage "
                    + action.substring(11) + '\n');
        }
        else if (action != null && action.equals("house"))
        {
            messages.append(
                player + " just paid the banker " + amount1 + " million to build a house on "
                    + action.substring(6) + '\n');
        }
        else
        {
            messages.append(player + " just paid the banker " + amount1 + " million for " + action);
        }
    }


    /**
     * Shows when the bank pays a player.
     *
     * @param player
     *            player getting paid
     * @param amount1
     *            amount in mil
     * @param action
     *            filter for why they are getting paid. Must be a Card type or
     *            mortgage.
     * @precondition the action var must be "Community Chest", "go", "Chance",
     *               or "mortgage ..." (followed by property name)
     */
    public void bankPaid(String player, double amount1, String action)
    {
        if (action == null) return;
        if ((action.equals("Community Chest") || action.equals("Chance")))
        {
            messages.append(
                player + " just got paid " + amount1 + " million due to the " + action + "card"
                    + '\n');
        }
        else if (action.equals("go"))
        {
            messages.append(player + " just passed go and collected " + amount1 + '\n');
        }
        else if (action.contains("mortgage"))
        {
            messages.append(
                player + " just mortgaged " + action.substring(8) + " for " + amount1 + '\n');
        }
        else if (action.contains("sell house"))
        {
            messages.append(
                player + " just sold their house on " + action.substring(11) + " for " + amount1
                    + '\n');
        }
        else
        {
            messages.append("The card says " + action + "\n");
        }
    }


    /**
     * Shows when a Player owes another player money.
     *
     * @param toPay
     *            who needs to pay
     * @param gettingPaid
     *            who is getting paid
     * @param amount1
     *            amount in mil
     * @param action
     *            why they are getting paid (see precondition)
     * @precondition action must be "rent", "Community Chest", or "Chance",
     */
    public void owedMoney(String toPay, String gettingPaid, double amount1, String action)
    {
        if (action.contains("rent"))
        {
            messages.append(
                toPay + " just paid " + gettingPaid + " " + amount1 + " million for rent on "
                    + action.substring(5) + '\n');
        }
        else if (action.equals("Community Chest") || action.equals("Chance"))
        {
            messages.append(
                toPay + " just paid " + gettingPaid + " " + amount1 + " million due to the "
                    + action + "card" + '\n');
        }
        else
        {
            messages.append("error" + '\n');
        }
    }

// Methods used when displaying what property a player landed on


    /**
     * Displays if a player landed on an unowned property and if they have
     * enough to buy it.
     *
     * @param player
     *            player who landed
     * @param property
     *            property String title
     * @param buy
     *            the integer parameter from the Player class representing if
     *            they can buy it, if they need to mortgage to buy it, or if
     *            they cant buy it
     * @precondition buy must be 1, 2, or 3
     */
    public void canBuy(String player, String property, int buy)
    {
        if (buy == 0)
        {
            messages
                .append(player + " landed on " + property + " and has enough to buy it!" + '\n');
        }
        if (buy == 1)
        {
            messages.append(
                player + " landed on " + property + " but needs to mortgage properties to buy it."
                    + '\n');
        }
        if (buy == 2)
        {
            messages.append(
                player + " landed on " + property + "but can't buy it, even with mortgage" + '\n');
        }
    }


    /**
     * Displays whose turn it is, handles doubles.
     *
     * @param player
     *            whose turn it is (string player name)
     * @param isAgain
     *            boolean representing if its a double and a roll again or not
     */
    public void Turn(String player, boolean isAgain)
    {
        if (!isAgain)
        {
            messages.append("It is now " + player + "'s turn!" + '\n');
        }
        else
        {
            messages.append(player + " had rolled doubles last turn. Roll again! \n");
        }
    }


    /**
     * Handles all other spots to land on.
     *
     * @param player
     *            who landed
     * @param action
     *            where the player is going
     */
    public void landedOnOther(String player, String action)
    {
        if (action.equals("Chance") || action.equals("Community Chest"))
        {
            messages
                .append(player + " just landed on a " + action + " card and will draw one!" + '\n');
            return;
        }
        else if (action.equals("jail"))
        {
            messages.append(player + " is going to jail!" + '\n');
        }
        else if (action.equals("house"))
        {
            messages.append(player + " can build houses!!" + +'\n');
        }
        else
        {
            messages.append(player + " landed on " + action + '\n');
        }

    }


    /**
     * Prints out the possible housing spots.
     *
     * @param player
     *            player to print
     * @param cards
     *            list of cards
     */
    public void houseTime(Player player, ArrayList<PropertyCard> cards)
    {
        String toPrint = player.getName() + " can build houses on ";
        for (int i = 0; i < cards.size(); i++)
        {
            toPrint += (cards.get(i).getName());
        }
        toPrint += "!" + '\n';
        messages.append(toPrint);
    }


    /**
     * Shows when a player landed on their own property..
     *
     * @param player
     *            whose doing the action
     */
    public void sameProperty(String player, String propertyName)
    {
        messages.append(player + " landed on their own property, " + propertyName + "!" + '\n');
    }

    public void moveTo(String title, Player player, String propertyName)
    {
        messages.append("The card says " + title + "/n" + player.getName() + " was moved to " + propertyName + " by the card! \n");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void actionPerformed(ActionEvent e)
    {
        messages.append("error");
    }
}
