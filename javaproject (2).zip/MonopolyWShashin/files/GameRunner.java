package files;

import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import javax.swing.*;
import javax.swing.border.*;

/**
 * the main executive class, implements the game setup process (Ex: how many
 * players, starting cash, player pieces, etc.) then calls the Board method to
 * create the GUI and holds the playing players in a “player” array. The
 * respective indices are set to false in the arrays “inJail” and “bankrupted”
 * when appropriate. Finally, this class handles turns and calls the “takeTurn”
 * method of the player class when appropriate .
 *
 * @author ojasgupta
 * @author shashingupta
 * @version May 11, 2021
 */
public class GameRunner
    extends JFrame
    implements ActionListener
{

    // private DeckOfChanceAndCommunityChestCards deck;
    private JFrame               frame;
    private JLabel               gamePrompt;
    private Container            c;
    private Box                  setupBox;
    private JButton              beginSetup;
    private JTextArea            setup;
    private JTextArea            EnterPlayerName;
    private JTextArea            EnterPlayerColor;
    private JTextArea            EnterPlayerType;
    private JScrollPane          originalPane;
    private ArrayList<String>    setUpInfo;
    private int                  PlayerCount;
    private boolean              doFirstSetup;
    private JButton              DoDefaultSetup;
    // for the game
    private JButton              startGame;
    private MessageCenter        messages;
    private DieRoll              die1;
    private DieRoll              die2;
    private static Graphics      g;
    private JPanel               p;
    private ArrayList<Player>    players;
    private PropertyCard[]       properties;
    private Decks                deck;
    private boolean[]            inJail          = { false, false, false, false };
    private int                  turnCount;
    private JPanel               contentIncluder;
    private Board                gameBoard;
    private CardLayout           c1;
    private JPanel               playerAssetsPanel;
    private JTextArea            player1;
    private JTextArea            player2;
    private JTextArea            player3;
    private JTextArea            player4;
    private JTextArea            player1Mon;
    private JTextArea            player2Mon;
    private JTextArea            player3Mon;
    private JTextArea            player4Mon;
    private boolean[]            bankrupted      = { false, false, false, false };
    private int                  bankruptedCount = 0;
    private double               player1Money;
    private double               player2Money;
    private double               player3Money;
    private double               player4Money;
    private boolean              isSim;
    private int simCount;
    public static final String[] NAMES           =
        { "Go", "Oriental Avenue", "Community Chest", "Vermont Avenue", "Connecticut Avenue",
            "Jail", "St. Charles Place", "Chance", "State Avenue", "Virgina Avenue", "Free Parking",
            "Kentucky Avenue", "Community Chest", "Indiana Avenue", "Illinois Avenue", "Go to Jail",
            "Pacific Avenue", "North Carolina Avenue", "Chance", "Pennsylvania Avenue" };

    /**
     * Launches the application.
     */

    public static void main(String[] args)
    {
        EventQueue.invokeLater(new Runnable() {
            public void run()
            {
                try
                {
                    GameRunner window = new GameRunner();
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
            }
        });
    }


    /**
     * returns the grahpics.
     *
     * @return Graphics g
     */
    public static Graphics getG()
    {
        return g;
    }


    /**
     * Create the main frame. All fields required to start the game without
     * crash are initialised in the constructor. When screen resolution is 1366
     * x 768 application starts, otherwise wrong resolution info is displayed
     */
    public GameRunner()
    {
        super("Monopoly Project Ojas && Shashin");
        getContentPane().setBackground(new Color(173, 216, 230));
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
        double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
        if (((int)width) == 1440 && ((int)height) == 900)
        {
            setUpInfo = new ArrayList<String>();
            deck = new Decks();
            players = new ArrayList<Player>();
            deck.makeProperties();
            properties = deck.getProperties();
            turnCount = 0;
            initialize();
        }
    }


    /**
     * Initialise the contents of the frame. All needed panels are created
     * before start of the actual game
     */
    private void initialize()
    {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        FlowLayout flow = new FlowLayout();
        flow.setHgap(0);
        flow.setVgap(0);
        frame = new JFrame("Monopoly Project Ojas && Shashin");
        frame.setLayout(flow);
        setLayout(flow);
        frame.getContentPane().setBackground(new Color(173, 216, 230));
        // frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setSize(screenSize);
        setSize(screenSize);
        frame.setResizable(false);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setup = new JTextArea(4, 30);
        simCount = 0;

        g = frame.getGraphics();

        setup.setLineWrap(true);
        setup.setWrapStyleWord(true);

        setup.setEditable(false);
        setup.setText(
            "Welcome to Monopoly! Click the button below to set up the game. There are 4 players, and each one can be computer or player controlled. Good luck!");
        originalPane = new JScrollPane(setup);
        setupBox = Box.createVerticalBox();
        setupBox.add(originalPane);
        c = frame.getContentPane();
        c.setLayout(flow);
        c.add(setupBox);
        beginSetup = new JButton("Click to begin setup!");
        beginSetup.setAlignmentX(Component.CENTER_ALIGNMENT);
        beginSetup.addActionListener(this);
        beginSetup.setVisible(true);
        DoDefaultSetup = new JButton("Click to do a default setup!");
        DoDefaultSetup.setAlignmentX(Component.CENTER_ALIGNMENT);
        DoDefaultSetup.addActionListener(this);
        DoDefaultSetup.setVisible(true);
        setupBox.add(beginSetup);
        setupBox.add(DoDefaultSetup);
        PlayerCount = 1;
        doFirstSetup = true;
    }


    /**
     * Begins the setup.
     *
     * @param a
     *            the integer to handle different setup cases
     */
    private void beginSetup(int a)
    {
        if (PlayerCount == 5)
        {
            frame.setVisible(false);
            setVisible(true);
            runGame();
            return;
        }
        doFirstSetup = false;
        EnterPlayerName = new JTextArea(2, 20);
        EnterPlayerColor = new JTextArea(2, 20);
        EnterPlayerType = new JTextArea(2, 20);
        EnterPlayerName.setLineWrap(true);
        EnterPlayerName.setWrapStyleWord(true);
        EnterPlayerColor.setLineWrap(true);
        EnterPlayerColor.setWrapStyleWord(true);
        EnterPlayerType.setLineWrap(true);
        EnterPlayerType.setWrapStyleWord(true);
        setup.setSize(1, 15);
        setup.setText("Enter the info for Player " + PlayerCount);
        EnterPlayerName.setText("<Enter Player" + PlayerCount + "'s name here>");
        EnterPlayerName.setEditable(true);
        EnterPlayerColor.setText(
            "<Choose a color for Player " + PlayerCount
                + ". It must be 'Red', 'Blue', 'Orange', or 'Green'>");
        EnterPlayerColor.setEditable(true);
        EnterPlayerType.setText(
            "<Enter type for Player " + PlayerCount + ". It must be 'Human' or 'Computer'>");
        EnterPlayerType.setEditable(true);
        JScrollPane pane1 = new JScrollPane(EnterPlayerName);
        JScrollPane pane2 = new JScrollPane(EnterPlayerColor);
        JScrollPane pane3 = new JScrollPane(EnterPlayerType);
        setupBox.add(pane1);
        setupBox.add(pane2);
        setupBox.add(pane3);
        c.add(setupBox);
        originalPane.setVisible(true);
        beginSetup = new JButton("Click if you are done entering values");
        setupBox.add(beginSetup);
        beginSetup.setVisible(true);
        beginSetup.addActionListener(this);
        if (a == 0)
        {
            PlayerCount++;
        }
        else if (a == 2)
        {
            setup.setText(
                "That color is already taken. Please re-enter the info for Player " + PlayerCount
                    + " and follow the instructions.");
        }
        else
        {
            setup.setText(
                "There was a problem with your inputs. Please re-enter the info for Player "
                    + PlayerCount + " and follow the instructions.");
        }

    }


    /**
     * Runs the new game frame.
     */
    private void runGame()
    {
        c = getContentPane();
        c.setLayout(new BorderLayout());
        p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setPreferredSize(new Dimension(350, 900));

        messages = new MessageCenter();
        originalPane = new JScrollPane(
            messages.getMessages(),
            ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
            ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        setupBox = Box.createVerticalBox();
        setupBox.add(originalPane);
        setupBox.setPreferredSize(new Dimension(350, 500));
        p.add(setupBox);
        die1 = new DieRoll();
        die2 = new DieRoll();
        die1.setBounds(1, 350, 1, 400);
        c.add(p, BorderLayout.LINE_START);
        rollDice();

        for (int i = 0; i < 12; i = i + 3)
        {
            if (setUpInfo.get(i).equalsIgnoreCase("h"))
            {
                players.add(
                    new HumanPlayer(
                        die1,
                        die2,
                        properties,
                        setUpInfo.get(i + 1),
                        this,
                        setUpInfo.get(i + 2),
                        0.1));
            }
            else
            {
                players.add(
                    new ComputerPlayer(
                        die1,
                        die2,
                        properties,
                        setUpInfo.get(i + 1),
                        this,
                        setUpInfo.get(i + 2),
                        0.1));
            }
        }
        player1Money = players.get(0).getMoney();
        player2Money = players.get(1).getMoney();
        player3Money = players.get(2).getMoney();
        player4Money = players.get(3).getMoney();

        // setup the board
        contentIncluder = new JPanel();
        contentIncluder.setBorder(new EmptyBorder(5, 5, 5, 5));
        c.add(contentIncluder, BorderLayout.CENTER);
        contentIncluder.setLayout(null);

        JLayeredPane layeredPane = new JLayeredPane();
        layeredPane.setBorder(new LineBorder(new Color(0, 0, 0)));
        layeredPane.setBounds(6, 6, 632, 630);
        contentIncluder.add(layeredPane);

        gameBoard = new Board(6, 6, 612, 612, players.get(0));
        gameBoard.setBackground(new Color(51, 255, 153));
        layeredPane.add(gameBoard, 0);
        PlayerPiece piece1 = players.get(0).getPlayerPiece();
        PlayerPiece piece2 = players.get(1).getPlayerPiece();
        PlayerPiece piece3 = players.get(2).getPlayerPiece();
        PlayerPiece piece4 = players.get(3).getPlayerPiece();
        gameBoard.add(piece1);
        piece1.initialize();
        piece1.setVisible(true);
        gameBoard.add(piece2);
        piece2.initialize();
        piece2.setVisible(true);
        gameBoard.add(piece3);
        piece3.initialize();
        piece3.setVisible(true);
        gameBoard.add(piece4);
        piece4.initialize();
        piece4.setVisible(true);
        gameBoard.paint(gameBoard.getGraphics());

        JPanel rightPanel = new JPanel();
        rightPanel.setBackground(Color.WHITE);
        rightPanel.setBorder(new LineBorder(new Color(0, 0, 0)));
        rightPanel.setBounds(634, 6, 419, 600);
        contentIncluder.add(rightPanel);
        rightPanel.setLayout(new FlowLayout());
        player1Mon = new JTextArea(1, 20);
        player1Mon.setLineWrap(true);
        player1Mon.setWrapStyleWord(true);
        player1Mon.setEditable(false);
        player1Mon.setVisible(true);
        player1Mon.setText(players.get(0).getName() + " has " + player1Money + " million");
        player1 = new JTextArea(3, 20);
        player1.setLineWrap(true);
        player1.setWrapStyleWord(true);
        player1.setEditable(false);
        player1.setVisible(true);
        player1.setText(" and the following properties: ");
        rightPanel.add(player1Mon);
        rightPanel.add(player1);
        player2Mon = new JTextArea(1, 20);
        player2Mon.setLineWrap(true);
        player2Mon.setWrapStyleWord(true);
        player2Mon.setEditable(false);
        player2Mon.setVisible(true);
        player2Mon.setText(players.get(1).getName() + " has " + player2Money + " million");
        player2 = new JTextArea(3, 20);
        player2.setLineWrap(true);
        player2.setWrapStyleWord(true);
        player2.setEditable(false);
        player2.setVisible(true);
        player2.setText(" and the following properties: ");
        rightPanel.add(player2Mon);
        rightPanel.add(player2);
        player3Mon = new JTextArea(1, 20);
        player3Mon.setLineWrap(true);
        player3Mon.setWrapStyleWord(true);
        player3Mon.setEditable(false);
        player3Mon.setVisible(true);
        player3Mon.setText(players.get(2).getName() + " has " + player3Money + " million");
        player3 = new JTextArea(3, 20);
        player3.setLineWrap(true);
        player3.setWrapStyleWord(true);
        player3.setEditable(false);
        player3.setVisible(true);
        player3.setText(" and the following properties: ");
        rightPanel.add(player3Mon);
        rightPanel.add(player3);
        player4Mon = new JTextArea(1, 20);
        player4Mon.setLineWrap(true);
        player4Mon.setWrapStyleWord(true);
        player4Mon.setEditable(false);
        player4Mon.setVisible(true);
        player4Mon.setText(players.get(3).getName() + " has " + player4Money + " million");
        player4 = new JTextArea(3, 20);
        player4.setLineWrap(true);
        player4.setWrapStyleWord(true);
        player4.setEditable(false);
        player4.setVisible(true);
        player4.setText(" and the following properties: ");
        rightPanel.add(player4Mon);
        rightPanel.add(player4);
        int count = 0;
        for (int i = 0; i < 4; i++)
        {
            if (players.get(i) instanceof ComputerPlayer)
            {
                count++;
            }
        }
        if (count == 4)
        {
            isSim = true;
        }
        else
        {
            isSim = false;
        }
        takeFirstTurn();
        return;
    }


    private void takeFirstTurn()
    {
        if (isSim)
        {
            startGame = new JButton("Click me to simulate the next four turns!");
        }
        else
        {
            startGame = new JButton("Click me when you are ready to start the game!");
        }
        startGame.setAlignmentX(Component.CENTER_ALIGNMENT);
        startGame.addActionListener(this);
        startGame.setVisible(true);
        c.add(startGame, BorderLayout.NORTH);
        return;
    }


    /**
     * REpresents when a player buys another property.
     *
     * @param player
     *            player who bought it
     * @param a
     *            integer to represent different cases
     */
    public void bought(Player player, int a)
    {
        int b = players.indexOf(player);
        if (b == 0)
        {
            player1.append(NAMES[a] + ", ");
        }
        if (b == 1)
        {
            player2.append(NAMES[a] + ", ");
        }
        if (b == 2)
        {
            player3.append(NAMES[a] + ", ");
        }
        if (b == 3)
        {
            player4.append(NAMES[a] + ", ");
        }
    }


    /**
     * Sets the respective index of a player to true in the bankrupted array.
     *
     * @param player
     *            String name of player to be bankrupted
     */
    public void bankrupt(String player)
    {
        if (players.get(0).getName().equals(player))
        {
            bankrupted[0] = true;
        }
        if (players.get(1).getName().equals(player))
        {
            bankrupted[1] = true;
        }
        if (players.get(2).getName().equals(player))
        {
            bankrupted[2] = true;
        }
        if (players.get(3).getName().equals(player))
        {
            bankrupted[3] = true;
        }
    }

    private void updateMoney()
    {
        player1Money = players.get(0).getMoney();
        player2Money = players.get(1).getMoney();
        player3Money = players.get(2).getMoney();
        player4Money = players.get(3).getMoney();
        BigDecimal bigDecimal = new BigDecimal(String.valueOf(player1Money));
        bigDecimal = bigDecimal.setScale(3, RoundingMode.HALF_UP);
        player1Money = bigDecimal.doubleValue();
        BigDecimal bigDecimal2 = new BigDecimal(String.valueOf(player2Money));
        bigDecimal = bigDecimal2.setScale(3, RoundingMode.HALF_UP);
        player2Money = bigDecimal2.doubleValue();
        BigDecimal bigDecimal3 = new BigDecimal(String.valueOf(player3Money));
        bigDecimal = bigDecimal3.setScale(3, RoundingMode.HALF_UP);
        player3Money = bigDecimal3.doubleValue();
        BigDecimal bigDecimal4 = new BigDecimal(String.valueOf(player4Money));
        bigDecimal = bigDecimal4.setScale(3, RoundingMode.HALF_UP);
        player4Money = bigDecimal4.doubleValue();
        player1Mon.setText(players.get(0).getName() + " has " + player1Money + " million");
        player2Mon.setText(players.get(1).getName() + " has " + player2Money + " million");
        player3Mon.setText(players.get(2).getName() + " has " + player3Money + " million");
        player4Mon.setText(players.get(3).getName() + " has " + player4Money + " million");
        return;
    }

    /**
     * Takes the next turn. Is called by the Player classes.
     */
    public void takeNextTurn()
    {
        simCount++;
        updateMoney();
        if (isSim && simCount % 5 == 0)
        {
            startGame = new JButton("Click me to simulate the next four turns!");

            startGame.setAlignmentX(Component.CENTER_ALIGNMENT);
            startGame.addActionListener(this);
            startGame.setVisible(true);
            c.add(startGame, BorderLayout.NORTH);
            return;
        }
        if (bankruptedCount == 3)
        {
            if (!bankrupted[0])
            {
                setVisible(false);
                JFrame winner = new JFrame(players.get(0).getName() + " is the Winner!!");
                winner.setVisible(true);
                return;
            }
            if (!bankrupted[1])
            {
                setVisible(false);
                JFrame winner = new JFrame(players.get(1).getName() + " is the Winner!!");
                winner.setVisible(true);
                return;
            }
            if (!bankrupted[2])
            {
                setVisible(false);
                JFrame winner = new JFrame(players.get(2).getName() + " is the Winner!!");
                winner.setVisible(true);
                return;
            }
            if (!bankrupted[3])
            {
                setVisible(false);
                JFrame winner = new JFrame(players.get(3).getName() + " is the Winner!!");
                winner.setVisible(true);
                return;
            }
        }
        turnCount++;
        if (turnCount == 4)
        {
            turnCount = 0;
        }
        if (bankrupted[turnCount])
        {
            turnCount++;
            return;
        }

        if (inJail[turnCount])
        {
            players.get(turnCount).takeJailTurn();
            return;
        }
        players.get(turnCount).takeTurn();
        return;
    }


    /**
     * Moves a player to jail by setting the appropriate value to true in the
     * array.
     *
     * @param player
     *            string name of player to be put in jail
     */
    public void moveToJail(String player)
    {
        if (players.get(0).getName().equals(player))
        {
            inJail[0] = true;
        }
        if (players.get(1).getName().equals(player))
        {
            inJail[1] = true;
        }
        if (players.get(2).getName().equals(player))
        {
            inJail[2] = true;
        }
        if (players.get(3).getName().equals(player))
        {
            inJail[3] = true;
        }
    }


    /**
     * frees a player from jail by setting the appropriate value to false in the
     * is in jail array.
     *
     * @param player
     *            player to be freed
     */
    public void freeFromJail(Player player)
    {
        inJail[players.indexOf(player)] = false;
    }


    /**
     * Handles if a player rolls doubles while in jail.
     *
     * @param a
     *            true if it is a double, false if not
     * @return a boolean on whether or not the player should continue
     */
    public boolean jailCheck(boolean a)
    {
        if (a)
        {
            turnCount--;
            takeNextTurn();
            return true;
        }
        return false;
    }


    /**
     * Handles the graphics for rolling the die.
     */
    public void rollDice()
    {
        JPanel dieBox = new JPanel() {
            @Override
            protected void paintComponent(Graphics grphcs)
            {
                super.paintComponent(grphcs);
                g = grphcs;
                die1.roll();
                die1.setGraphics(g);
                die2.roll();
                die2.setGraphics(g);
            }


            @Override
            public Dimension getPreferredSize()
            {
                return new Dimension(350, 400);
            }
        };
        dieBox.setVisible(true);
        p.add(dieBox);
        die1.roll();
        die2.roll();
        // die1.draw();
        // die2.draw();
        dieBox.repaint();

        // die1.avoidCollision(die2); causes a bug TODO
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource() == beginSetup)
        {
            if (doFirstSetup)
            {
                beginSetup.setVisible(false);
                beginSetup(0);
            }
            else if (PlayerCount < 6)
            {
                String a = EnterPlayerColor.getText();
                String b = EnterPlayerType.getText();
                if ((a.equalsIgnoreCase("red") || a.equalsIgnoreCase("blue")
                    || a.equalsIgnoreCase("Orange") || a.equalsIgnoreCase("Green"))
                    && (b.equalsIgnoreCase("Human") || b.equalsIgnoreCase("computer")))
                {
                    if (a.equalsIgnoreCase("red")
                        && (setUpInfo.size() == 0 || !setUpInfo.contains("r")))
                    {
                        setUpInfo.add(b.substring(0, 1));
                        setUpInfo.add(EnterPlayerName.getText());
                        setUpInfo.add("r");
                        beginSetup.setVisible(false);
                        System.out.println(setUpInfo.size());
                        beginSetup(0);
                    }
                    else if (a.equalsIgnoreCase("blue")
                        && (setUpInfo.size() == 0 || !setUpInfo.contains("b")))
                    {
                        setUpInfo.add(b.substring(0, 1));
                        setUpInfo.add(EnterPlayerName.getText());
                        setUpInfo.add("b");
                        beginSetup.setVisible(false);
                        System.out.println(setUpInfo.size());

                        beginSetup(0);
                    }
                    else if (a.equalsIgnoreCase("orange")
                        && (setUpInfo.size() == 0 || !setUpInfo.contains("o")))
                    {
                        setUpInfo.add(b.substring(0, 1));
                        setUpInfo.add(EnterPlayerName.getText());
                        setUpInfo.add("o");
                        beginSetup.setVisible(false);
                        System.out.println(setUpInfo.size());

                        beginSetup(0);
                    }
                    else if (a.equalsIgnoreCase("green")
                        && (setUpInfo.size() == 0 || !setUpInfo.contains("g")))
                    {
                        setUpInfo.add(b.substring(0, 1));
                        setUpInfo.add(EnterPlayerName.getText());
                        setUpInfo.add("g");
                        beginSetup.setVisible(false);
                        System.out.println(setUpInfo.size());

                        beginSetup(0);
                    }
                    else
                    {
                        beginSetup(2);
                    }
                }
                else
                {
                    beginSetup(1);
                }
            }
            else
            {
                frame.setVisible(false);
                setVisible(true);
                runGame();
            }
        }
        if (e.getSource() == DoDefaultSetup)
        {
            frame.setVisible(false);
            setVisible(true);
            setUpInfo.add("c");
            setUpInfo.add("Player1");
            setUpInfo.add("R");
            setUpInfo.add("c");
            setUpInfo.add("Player2");
            setUpInfo.add("O");
            setUpInfo.add("c");
            setUpInfo.add("Player3");
            setUpInfo.add("G");
            setUpInfo.add("c");
            setUpInfo.add("Player4");
            setUpInfo.add("b");
            runGame();
        }
        if (e.getSource() == startGame)
        {
            if (!isSim)
            {
                startGame.setVisible(false);
                players.get(0).takeTurn();
            }
            else if (simCount > 2)
            {
                startGame.setVisible(false);
                simCount++;
                takeNextTurn();
            }
            else
            {
                startGame.setVisible(false);
                simCount++;
                players.get(0).takeTurn();
            }
        }
    }


    /**
     * Gets the message Center.
     *
     * @return MessageCEnter
     */
    public MessageCenter messageCenter()
    {
        return messages;
    }


    /**
     * Draws a community chest card.
     *
     * @return Card object
     */
    public Cards drawComChest()
    {
        return deck.draw("cc");
    }


    /**
     * Draws a chance card.
     *
     * @return Card object
     */
    public Cards drawChance()
    {
        return deck.draw("chance");
    }
}
