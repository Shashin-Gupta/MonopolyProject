package files;

import java.util.ArrayList;

/**
 * Implements the Player class as a HumanPlayer, by giving the Player a manual
 * input/option to do the actions. However, most rent/transactions are
 * automatic, unless mortgaging is needed Implements the same methods as
 * ComputerPlayer from Player but with GUI to handle the human player’s
 * requests. The GUI is represented in the PlayerWindow class.
 *
 * @author ojasgupta
 * @version May 12, 2021
 */
public class HumanPlayer
    extends Player
{
    // ~ Fields ................................................................
    private PlayerWindow window;
    private PropertyCard processing;
    private boolean      isRollAgain;
    private boolean      rentDouble;
    private int          turnsInJail;

    // ~ Constructors ..........................................................
    /**
     * Creates a new HumanPlayer object, starting money default 15 mil
     *
     * @param a
     *            The first die (super constructor)
     * @param b
     *            the second die (super constructor)
     * @param s
     *            The array of Property cards (super constructor)
     * @param name
     *            The name of the player (super constructor)
     * @param x
     *            GameRunner associated with this player (super constructor)
     * @param color
     *            color of player piece
     * @param factor
     *            The factor at which transactions proceed at
     */
    public HumanPlayer(
        DieRoll a,
        DieRoll b,
        PropertyCard[] s,
        String name,
        GameRunner x,
        String color,
        double factor)
    {
        super(a, b, s, name, x, color, factor);
        window = new PlayerWindow(this);
        isRollAgain = false;
        rentDouble = false;
    }


    /**
     * Creates a new HumanPlayer object, money is now a parameter
     *
     * @param a
     *            The first die (super constructor)
     * @param b
     *            the second die (super constructor)
     * @param s
     *            The array of Property cards (super constructor)
     * @param name
     *            The name of the player (super constructor)
     * @param x
     *            GameRunner associated with this player (super constructor)
     * @param startAmount
     *            starting money amount *
     * @param color
     *            color of player piece
     * @param factor
     *            The factor at which transactions proceed at
     */
    public HumanPlayer(
        DieRoll a,
        DieRoll b,
        PropertyCard[] s,
        String name,
        GameRunner x,
        double startAmount,
        String color,
        double factor)
    {
        super(startAmount, a, b, s, name, x, color, factor);
        window = new PlayerWindow(this);
        isRollAgain = false;
    }


    // ~Public Methods ........................................................
    /**
     * {@inheritDoc}
     */
    public void takeTurn()
    {
        turnsInJail = 0;
        super.Messages().Turn(super.getName(), isRollAgain);
        window.goTime();
    }


    /**
     * Called by the Player Window when the "Roll the Die" button is clicked.
     * Rolls the die and calls the "TurnOptions" class with the PropertyCard to
     * analyze.
     */
    public void doTurn()
    {
        int[] a = super.rollTheDie();
        processing = super.diceAnalysis(a[0], a[1]);
        TurnOptions(processing);
    }


    /**
     * Analyzes the PropertyCard landed on and handles all the outcomes, calling
     * respective helper methods. All outcomes end in calling the "houses"
     * method in the Player class (or calls other methods that end with the
     * houses method), which checks if a player can build houses/hotels before
     * their turn ends. The parameter is needed because of the Cards that might
     * send a player directly to a property, without rolling the die. Thus, a
     * parameter was created to handle taking a turn even when the die isn't
     * rolled
     *
     * @param card
     *            Property Card to analyze
     */
    public void TurnOptions(PropertyCard card)
    {
        this.processing = card;
        ArrayList<PropertyCard> ownedCards = super.getProperties();
        if (processing == null)
        {
            System.out.print("WARNING WARNING " + super.getPosition());
            return;
        }
        if (processing.getType() != null && processing.getType().equals("Community Chest"))
        {
            super.Messages().landedOnOther(super.getName(), "Community Chest");
            Cards a = super.getGameRunner().drawComChest();
            a.setOwner(this);
            a.doAction();
            return;
        }
        else if (processing.getType() != null && processing.getType().equals("Chance"))
        {
            super.Messages().landedOnOther(super.getName(), "Chance");
            Cards a = super.getGameRunner().drawChance();
            a.setOwner(this);
            a.doAction();
            return;
        }
        else if (processing.getType() != null && (processing.getType().equals("Income Tax")
            || processing.getType().equals("Luxury Tax")))
        {
            if (super.canPay(2.0) == 0)
            {
                Transaction b = new Transaction(transactionFactor, super.Messages());
                String phrase = "Income Tax";
                b.payBank(this, 2.0, phrase);
                houses();
                return;
            }
            window.setPayAmount(2.0);
            // makes the player mortgage enough properties/sell
            // enough
            // houses to pay rent
            // also has a give up button
            return;
        }
        else if (processing.getType() != null && processing.getType().equals("GoToJail"))
        {
            super.Messages().landedOnOther(super.getName(), "jail");
            super.goToJail();
            houses();
            return;
        }
        else if (processing.getType() != null && processing.getType().equals("free"))
        {
            super.Messages().landedOnOther(super.getName(), processing.getName());
            houses();
            return;
        }
        else
        {
            for (PropertyCard b : ownedCards)
            {
                if (b.equals(processing))
                {
                    try
                    {
                        Thread.sleep((int)(1000.0 * transactionFactor));
                    }
                    catch (InterruptedException e)
                    {
                        e.printStackTrace();
                    }
                    super.Messages().sameProperty(super.getName(), processing.getName());
                    houses();
                    return;
                }
            }

            if (processing.isOwned())
            {
                checkIfBuy();
            }
            else
            {
                if (rentDouble)
                {
                    if (super.canPay(processing.getRent() * 2) == 0)
                    {
                        Transaction b = new Transaction(transactionFactor, super.Messages());
                        String phrase = "rent " + processing.getName();
                        b.payPlayer(this, processing.getOwner(), processing.getRent() * 2, phrase);
                        houses();
                        return;
                    }
                    window.setPayAmount(processing.getRent() * 2);
                    // makes the player mortgage enough properties/sell
                    // enough
                    // houses to pay rent
                    // also has a give up button
                    Transaction b = new Transaction(transactionFactor, super.Messages());
                    String phrase = "rent " + processing.getName();
                    b.payPlayer(this, processing.getOwner(), processing.getRent() * 2, phrase);
                    houses();
                    return;
                }
                if (super.canPay(processing.getRent()) != 0)
                {
                    window.setPayAmount(processing.getRent());
                }
                Transaction b = new Transaction(transactionFactor, super.Messages());
                String phrase = "rent " + processing.getName();
                b.payPlayer(this, processing.getOwner(), processing.getRent(), phrase);
                houses();
                return;
            }
        }
    }


    /**
     * Helper method. Checks if a Player can buy a property and calls the
     * PlayerWindow functions when appropriate. Calls mortgaging as well
     */
    private void checkIfBuy()
    {
        int canBuy = super.canPay(processing.getPropertyValue());
        super.Messages().canBuy(super.getName(), processing.getName(), canBuy);
        if (canBuy == 0)
        {
            window.buyTime();
            return;
        }
        else if (canBuy == 1)
        {
            window.buyTime();
            return;
        }
        else
        {
            houses();
            return;
        }
    }


    /**
     * Mortgages a property.
     *
     * @param a
     *            PropertyCard to be mortgaged
     * @param b
     *            selling house or not
     */
    public void mortgage(PropertyCard a, boolean b)
    {
        if (a.getHouseInfo()[1] == 0 && !b)
        {
            // TODO any graphics??
            Transaction c = new Transaction(transactionFactor, super.Messages());
            String phrase = "mortgage " + a.getName();
            c.payBank(this, -1 * a.getPropertyValue() / 2, phrase);
        }
        else
        {
            Transaction c = new Transaction(transactionFactor, super.Messages());
            String phrase = "sell house " + a.getName();
            c.payBank(this, -1 * a.getHouseInfo()[0] / 2, phrase);
        }
    }


    /**
     * Unmortgages a property.
     *
     * @param a
     *            propertyCard to unmortgage
     */
    public void unmortgage(PropertyCard a)
    {
        // TODO any graphics??
        Transaction b = new Transaction(transactionFactor, super.Messages());
        String phrase = "unmortgage  " + a.getName();
        b.payBank(this, a.getPropertyValue() / 2 * 1.1, phrase);
    }


    /**
     * Is called by the PlayerWindow method when a Player buys a property.
     */
    public void bought()
    {
        super.addProperty(processing);
        super.getGameRunner().bought(this, super.getPosition());
        processing.setOwner(this);
        Transaction purchase = new Transaction(transactionFactor, super.Messages());
        String buyPhrase = "buy " + processing.getName();
        purchase.payBank(this, processing.getPropertyValue(), buyPhrase);
        houses();
        return;
    }


    /**
     * Ends the turn, usually called after checking if houses can be built in
     * the houses() method. Communicates with the GR that the turn is done
     */
    public void turnDone()
    {
        window.turnDone();
        super.getGameRunner().takeNextTurn();
        return;
    }


    /**
     * {@inheritDoc}
     */
    public void houses()
    {
        ArrayList<PropertyCard> possibleSpots = super.canBuild();
        if (possibleSpots.size() == 0)
        {
            turnDone();
            return;
        }
        int i = 0;
        while (i < possibleSpots.size())
        {
            if (possibleSpots.get(i).getHouseInfo()[1] == 5)
            {
                possibleSpots.remove(i);
            }
            else
            {
                i++;
            }
        }
        if (possibleSpots.size() == 0)
        {
            turnDone();
            return;
        }
        super.Messages().houseTime(this, possibleSpots);
        window.houseTime(possibleSpots);
        return;
    }


    /**
     * Called by the window class to build a hosue.
     *
     * @param a
     *            propertyCard getting a house
     */
    public void buildHouse(PropertyCard a)
    {
        Transaction purchase = new Transaction(transactionFactor, super.Messages());
        String buyPhrase = "house " + a.getName();
        purchase.payBank(this, a.getHouseInfo()[0], buyPhrase);
        a.addHouse();
        // TODO graphics?
    }


    /**
     * {@inheritDoc}
     */
    public void takeJailTurn()
    {
        super.Messages().Turn(super.getName(), isRollAgain);
        turnsInJail++;
        if (turnsInJail == 3)
        {
            payJail();
            return;
        }
        window.goJailTime();
    }


    /**
     * Handles a turn in Jail.
     */
    public void doJailTurn()
    {
        int[] a = super.rollTheDie();
        // TODO jail ??
        if (super.getGameRunner().jailCheck(a[0] == a[1]))
        {
            return;
        }
        turnDone();
        return;
    }


    /**
     * Handles when a Player chooses to pay jail.
     */
    public void payJail()
    {
        Transaction a = new Transaction(transactionFactor, super.Messages());
        a.payBank(this, 0.5, "jail");
        super.getGameRunner().freeFromJail(this);
        try
        {
            Thread.sleep((int)(1000.0 * transactionFactor));
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
        takeTurn();
    }


    /**
     * {@inheritDoc}
     */
    public double getFactor()
    {
        return transactionFactor;
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public void TurnAfterChanceMoved()
    {
        if (super.getPosition() == 9 || super.getPosition() == 8)
        {
            rentDouble = true;
        }
        TurnOptions(super.newProperty());
    }
}
