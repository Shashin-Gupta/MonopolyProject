package files;

import java.util.ArrayList;

/**
 * Represents the AI computer implementation of the player class. Contains smart
 * decision making ability. DOes not have a window to take decisions extends
 * Player
 *
 * @author ojasgupta
 * @version May 20, 2021
 */
public class ComputerPlayer
    extends Player
{
    // ~ Fields ................................................................
    private PropertyCard processing;
    private boolean      isRollAgain;
    private int          turnsTaken;
    private final int    endGame  = 5000;
    private boolean      rentDouble;
    private int          jailTurn = 0;

    // ~ Constructors ..........................................................

    /**
     * Creates a new Computer object, money is default 15 mil
     *
     * @param a
     *            The first die (super constructor)
     * @param b
     *            the second die (super constructor)
     * @param s
     *            The array of Property cards (super constructor)
     * @param name
     *            The name of the player (super constructor)
     * @param x
     *            GameRunner associated with this player (super constructor)
     * @param color
     *            color of player piece
     * @param factor
     *            The factor at which transactions proceed at
     */
    public ComputerPlayer(
        DieRoll a,
        DieRoll b,
        PropertyCard[] s,
        String name,
        GameRunner x,
        String color,
        double factor)
    {
        super(a, b, s, name, x, color, factor);
        isRollAgain = false;
        turnsTaken = 0;
        rentDouble = false;
    }


    /**
     * Creates a new Computer object, money is now a parameter
     *
     * @param a
     *            The first die (super constructor)
     * @param b
     *            the second die (super constructor)
     * @param s
     *            The array of Property cards (super constructor)
     * @param name
     *            The name of the player (super constructor)
     * @param x
     *            GameRunner associated with this player (super constructor)
     * @param startAmount
     *            starting money amount
     * @param color
     *            color of player piece
     * @param factor
     *            The factor at which transactions proceed at
     */
    public ComputerPlayer(
        DieRoll a,
        DieRoll b,
        PropertyCard[] s,
        String name,
        GameRunner x,
        double startAmount,
        String color,
        double factor)
    {
        super(startAmount, a, b, s, name, x, color, factor);
        isRollAgain = false;
        turnsTaken = 0;
        rentDouble = false;
    }

    // ~Public Methods ........................................................


    /**
     * {@inheritDoc}
     */
    @Override
    public void takeTurn()
    {
        // System.out.print("made it!");
        turnsTaken++;
        jailTurn = 0;
        super.Messages().Turn(super.getName(), isRollAgain);
        int[] a = super.rollTheDie();
        processing = super.diceAnalysis(a[0], a[1]);
        try
        {
            Thread.sleep((int)(3000.0 * transactionFactor));
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
        takeTurnHelper(processing);
    }


    private void takeTurnHelper(PropertyCard b)
    {
        processing = b;
        ArrayList<PropertyCard> ownedCards = super.getProperties();
        if (processing == null)
        {
            System.out.print("WARNING WARNING " + super.getPosition());
            return;
        }
        else if (processing.getType() != null && processing.getType().equals("Community Chest"))
        {
            super.Messages().landedOnOther(super.getName(), "Community Chest");
            Cards a = super.getGameRunner().drawComChest();
            a.setOwner(this);
            a.doAction();
            return;
        }
        else if (processing.getType() != null && processing.getType().equals("Chance"))
        {
            super.Messages().landedOnOther(super.getName(), "Chance");
            Cards a = super.getGameRunner().drawChance();
            a.setOwner(this);
            a.doAction();
            return;
        }
        else if (processing.getType() != null && processing.getType().equals("GoToJail"))
        {
            super.Messages().landedOnOther(super.getName(), "jail");
            super.goToJail();
            houses();
            return;
        }

        else if (processing.getType() != null && processing.getType().equals("free"))
        {
            super.Messages().landedOnOther(super.getName(), processing.getName());
            houses();
            return;
        }
        else if (ownedCards.size() != 0)
        {
            for (PropertyCard c : ownedCards)
            {
                if (c.equals(processing))
                {
                    super.Messages().sameProperty(super.getName(), processing.getName());
                    houses();
                    return;
                }
            }
        }
        else if (processing.isOwned())
        {
            checkIfBuy();
        }
        else
        {
            if (rentDouble)
            {
                if (super.canPay(processing.getRent() * 2) == 0)
                {
                    Transaction d = new Transaction(transactionFactor, super.Messages());
                    String phrase = "rent " + processing.getName();
                    d.payPlayer(this, processing.getOwner(), processing.getRent(), phrase);
                    houses();
                }
                else
                {
                    if (super.canPay(processing.getRent() * 2) == 2)
                    {
                        giveUp();
                        return;
                    }
                    mortgageTill(processing.getRent() * 2);
                    Transaction d = new Transaction(transactionFactor, super.Messages());
                    String phrase = "rent " + processing.getName();
                    d.payPlayer(this, processing.getOwner(), processing.getRent() * 2, phrase);
                    houses();
                }
            }
            else
            {
                if (super.canPay(processing.getRent()) == 0)
                {
                    Transaction d = new Transaction(transactionFactor, super.Messages());
                    String phrase = "rent " + processing.getName();
                    d.payPlayer(this, processing.getOwner(), processing.getRent(), phrase);
                    houses();
                }
                else
                {
                    if (super.canPay(processing.getRent()) == 2)
                    {
                        giveUp();
                        return;
                    }
                    mortgageTill(processing.getRent());
                    Transaction d = new Transaction(transactionFactor, super.Messages());
                    String phrase = "rent " + processing.getName();
                    d.payPlayer(this, processing.getOwner(), processing.getRent(), phrase);
                    houses();
                }
            }
        }
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public void takeJailTurn()
    {
        jailTurn++;
        super.Messages().Turn(super.getName(), isRollAgain);
        if (jailTurn < 3 || super.getMoney() < 1.0 || turnsTaken > endGame)
        {
            int[] a = super.rollTheDie();
            try
            {
                Thread.sleep((int)(3000.0 * transactionFactor));
            }
            catch (InterruptedException e)
            {
                e.printStackTrace();
            }
            if (super.getGameRunner().jailCheck(a[0] == a[1]))
            {
                return;
            }
        }
        Transaction a = new Transaction(transactionFactor, super.Messages());
        a.payBank(this, 0.5, "jail");
        super.getGameRunner().freeFromJail(this);
        try
        {
            Thread.sleep((int)(1000.0 * transactionFactor));
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
        takeTurn();
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public double getFactor()
    {
        return transactionFactor;
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public void TurnAfterChanceMoved()
    {
        if (super.getPosition() == 9 || super.getPosition() == 8)
        {
            rentDouble = true;
        }
        takeTurnHelper(super.newProperty());
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public void houses()
    {
        for (int i = 0; i < super.getProperties().size(); i++)
        {
            if (super.getProperties().get(i).isMortgaged()
                && super.canPay(super.getProperties().get(i).getPropertyValue() / 2 * 1.1) == 0)
            {
                Transaction b = new Transaction(transactionFactor, super.Messages());
                String phrase = "unmortgage  " + super.getProperties().get(i).getName();
                b.payBank(this, super.getProperties().get(i).getPropertyValue() / 2 * 1.1, phrase);
            }
        }
        ArrayList<PropertyCard> possibleSpots = super.canBuild();
        if (possibleSpots.size() == 0)
        {
            turnDone();
            return;
        }
        int i = 0;
        while (i < possibleSpots.size())
        {
            if (possibleSpots.get(i).getHouseInfo()[1] == 5)
            {
                possibleSpots.remove(i);
            }
            else
            {
                i++;
            }
        }
        if (possibleSpots.size() == 0)
        {
            turnDone();
            return;
        }
        super.Messages().houseTime(this, possibleSpots);
        i = possibleSpots.size() - 1;
        while (i <= 0 && super.canPay(possibleSpots.get(i).getHouseInfo()[0]) == 0)
        {
            Transaction purchase = new Transaction(transactionFactor, super.Messages());
            String buyPhrase = "house " + possibleSpots.get(i).getName();
            purchase.payBank(this, possibleSpots.get(i).getHouseInfo()[0], buyPhrase);
            possibleSpots.get(i).addHouse();
            // TODO graphics
            if (possibleSpots.get(i).getHouseInfo()[1] == 5)
            {
                i--;
            }
        }
        return;
    }


    /**
     * Ends the turn, usually called after checking if houses can be built in
     * the houses() method. Communicates with the GR that the turn is done
     */
    private void turnDone()
    {
        super.getGameRunner().takeNextTurn();
    }


    private void checkIfBuy()
    {
        int canBuy = super.canPay(processing.getPropertyValue());
        super.Messages().canBuy(super.getName(), processing.getName(), canBuy);
        if (canBuy == 0 && super.getMoney() - processing.getPropertyValue() > 0.5)
        {
            // auto buys if the player will have over 500k after making the
            // purchase
            buy();
            return;
        }
        else if (isWorthBuying() && (canBuy == 0 || canBuy == 1))
        {
            mortgageTill(processing.getPropertyValue());
            buy();
            return;
        }
        houses();
        return;
    }


    private void buy()
    {
        super.addProperty(processing);
        super.getGameRunner().bought(this, super.getPosition());
        processing.setOwner(this);
        Transaction purchase = new Transaction(transactionFactor, super.Messages());
        String buyPhrase = "buy " + processing.getName();
        purchase.payBank(this, processing.getPropertyValue(), buyPhrase);
        houses();
    }


    private boolean isWorthBuying()
    {
        int sizeBefore = super.canBuild().size();
        super.addProperty(processing);
        int sizeAfter = super.canBuild().size();
        // checks if this is the third property of the color
        super.returnProperty(processing);
        if (turnsTaken < endGame || sizeBefore < sizeAfter)
        {
            return true;
        }
        return false;
    }


    private void mortgageTill(double priceToMeet)
    {
        ArrayList<PropertyCard> owned = super.getProperties();
        // sorted by property Value so it iterates over the least valuable
        // properties first. mortgages properties with less than 3 per
        // color
        int outerLoopCount = 0;
        while (outerLoopCount < owned.size())
        {
            int innerLoopCount = 0;
            int sameColoredProperties = 0;
            while (innerLoopCount < owned.size())
            {
                if (owned.get(outerLoopCount).getColor()
                    .equals(owned.get(innerLoopCount).getColor()))
                {
                    sameColoredProperties++;
                }
                innerLoopCount++;
            }
            if (sameColoredProperties < 3)
            {
                mortgage(owned.get(outerLoopCount), false);
            }
            if (priceToMeet <= super.getMoney())
            {
                return;
            }
            outerLoopCount++;
        }
        try
        {
            Thread.sleep((int)(1000.0 * transactionFactor));
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
        // if the player needs to sell properties where all three in a color are
        // owned, or sell houses, then it should reach the following loop
        int[] numOfHouses = new int[owned.size()];
        outerLoopCount = 0;
        for (PropertyCard a : owned)
        {
            numOfHouses[outerLoopCount] = (int)a.getHouseInfo()[1];
        }
        // prioritizes the mortgaging of properties without houses, then with 1
        // house, 2 houses, etc.
        for (int i = 0; i < numOfHouses.length; i++)
        {
            if (numOfHouses[i] == 0)
            {
                mortgage(owned.get(i), false);
            }
            if (priceToMeet <= super.getMoney())
            {
                return;
            }
        }
// 1 house
        try
        {
            Thread.sleep((int)(1000.0 * transactionFactor));
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
        for (int i = 0; i < numOfHouses.length; i++)
        {
            if (numOfHouses[i] == 1)
            {
                mortgage(owned.get(i), true);
            }
            if (priceToMeet <= super.getMoney())
            {
                return;
            }
            mortgage(owned.get(i), false);
            if (priceToMeet <= super.getMoney())
            {
                return;
            }
        }
// 2 houses
        try
        {
            Thread.sleep((int)(1000.0 * transactionFactor));
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
        for (int i = 0; i < numOfHouses.length; i++)
        {
            if (numOfHouses[i] == 2)
            {
                mortgage(owned.get(i), true);
            }
            if (priceToMeet <= super.getMoney())
            {
                return;
            }
            mortgage(owned.get(i), true);
            if (priceToMeet <= super.getMoney())
            {
                return;
            }
            mortgage(owned.get(i), false);
            if (priceToMeet <= super.getMoney())
            {
                return;
            }
        }
        // 3 houses
        try
        {
            Thread.sleep((int)(1000.0 * transactionFactor));
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
        for (int i = 0; i < numOfHouses.length; i++)
        {
            if (numOfHouses[i] == 3)
            {
                mortgage(owned.get(i), true);
            }
            if (priceToMeet <= super.getMoney())
            {
                return;
            }
            mortgage(owned.get(i), true);
            if (priceToMeet <= super.getMoney())
            {
                return;
            }
            mortgage(owned.get(i), true);
            if (priceToMeet <= super.getMoney())
            {
                return;
            }
            mortgage(owned.get(i), false);
            if (priceToMeet <= super.getMoney())
            {
                return;
            }
        }
        try
        {
            Thread.sleep((int)(2000.0 * transactionFactor));
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
        giveUp();
    }


    /**
     * Mortgages a property.
     *
     * @param a
     *            PropertyCard to be mortgaged
     * @param b
     *            selling house or not
     */
    private void mortgage(PropertyCard a, boolean b)
    {
        if (a.getHouseInfo()[1] == 0 && !b)
        {
            Transaction c = new Transaction(transactionFactor, super.Messages());
            String phrase = "mortgage " + a.getName();
            c.payBank(this, -1 * a.getPropertyValue() / 2, phrase);
        }
        else
        {
            Transaction c = new Transaction(transactionFactor, super.Messages());
            String phrase = "sell house " + a.getName();
            c.payBank(this, -1 * a.getHouseInfo()[0] / 2, phrase);
        }
    }

}
